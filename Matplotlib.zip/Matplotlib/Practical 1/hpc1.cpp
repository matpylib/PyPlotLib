#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<omp.h>
using namespace std;

int main()
{
	int n;
	cout<<"Enter no of elements:";
	cin>>n;
	int a[n],MAX=0,MIN=99999;
	int c=2*n;
	for(int i=0;i<n;i++)
	{
		a[i]=rand()%c;
	}

	//PARALLEL MAX
	clock_t c1=omp_get_wtime();
	#pragma omp parallel for reduction(max:MAX)
	for(int i=0;i<n;i++)
	{
		if(a[i]>MAX)
		{
			MAX=a[i];
		}
	}
	float t1=(float)(omp_get_wtime()-c1)/CLOCKS_PER_SEC;
	cout<<"MAX:"<<MAX<<endl;
	cout<<"Parallel execution time for max:"<<t1<<endl;

	//PARALLEL MIN
	clock_t c2=omp_get_wtime();
	#pragma omp parallel for reduction(min:MIN)
	for(int i=0;i<n;i++)
	{
		if(a[i]<MIN)
		{
			MIN=a[i];
		}
	}
	float t2=(float)(omp_get_wtime()-c2)/CLOCKS_PER_SEC;
	cout<<"MIN:"<<MIN<<endl;
	cout<<"Parallel execution time for min:"<<t2<<endl;


	//Serial MAX
	int MAX1=0;
	clock_t c3=clock();
	for(int i=0;i<n;i++)
	{
		if(a[i]>MAX1)
		{
			MAX1=a[i];
		}
	}
	float t3=(float)(clock()-c3)/CLOCKS_PER_SEC;
	cout<<"MAX:"<<MAX1<<endl;
	cout<<"Serial execution time for max:"<<t3<<endl;


	//SERIAL MIN
	int MIN1=99999;
	clock_t c4=clock();
	for(int i=0;i<n;i++)
	{
		if(a[i]<MIN1)
		{
			MIN1=a[i];
		}
	}
	float t4=(float)(clock()-c4)/CLOCKS_PER_SEC;
	cout<<"MIN:"<<MIN1<<endl;
	cout<<"Serial execution time for min:"<<t4<<endl;


	return 0;

}