#include<iostream>
#include<vector>
#include<unordered_map>
#include<map>
using namespace std;
int main()
{
	int n,temp,node,flag=0,goal;
	cout<<"Enter the no of nodes:-";
	cin>>n;
	
	int adj_mat[n][n]={0};
	vector<int>heu;
	vector<int>vis(n);
	
	cout<<"Enter the edge 1:present 2:Abscent";
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			cout<<"Edge Between " <<i<<"-->"<<j<<"=";
			cin>>temp;
			adj_mat[i][j] = temp;
			adj_mat[j][i] = temp;
		}
	
	}
	cout<<"ENter the heuristic value of nodes=";
	for(int i=0;i<n;i++)
	{
		 cout<<"Heuristic value of node "<<i+1<<" =";
		 cin>>temp;
		 heu.push_back(temp);
	}
	cout<<"Enter the goal node=";
	cin>>goal;
	
	multimap<int,int>m;
	unordered_map<int,int>cp;
	
	vis[0]=1;
	for(int i=1;i<n;i++)
	{
		if(adj_mat[0][i] == 1)
		{
			m.insert({heu[i],i});
			cp.insert({i,0});
			vis[i] = 1;
		}
	}
	
	cout<<"Nodes traversed are:-";
	
	while(m.size() != 0)
	{
		auto itr = m.begin();
		node = itr->second;
		cout<<node+1<<"->";
		if(node+1 == goal)
		{
			cout<<"Goal state found";
			flag =1;
			break;
		}
		m.erase(itr);
		for(int i=0;i<n;i++)
		{
			if(adj_mat[node][i] != 0 && vis[i] == 0)
			{
				m.insert({heu[i],i});
				cp.insert({i,node});
				vis[i] = 1;
			}
		}
	
	}
	cout<<endl;
	if(flag == 0)
	{
		cout<<"goal not found";
	}
	else
	{
		cout<<"The path from starting node to end node=";
		vector<int>ans;
		while(node != 0)
		{
			ans.push_back(node);
			node = cp[node];
		}
		ans.push_back(0);
		for(int i=0;i<ans.size();i++)
			cout<<" -> "<<ans[i]+1;
	}
	

	return 0;
}
