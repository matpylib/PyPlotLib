#include<iostream>
#include<omp.h>
#include<time.h>
#include<stdlib.h>
using namespace std;

int main()
{
	int mat[3][3],vec1[3],vec2[3],out[3],veco[3],out1[3],veco1[3];

	for(int row=0;row<3;row++)
	{
		for(int col=0;col<3;col++)
		{
			mat[row][col]=rand()%300;
		}
	}

	cout<<"Matrix:";
	for(int row=0;row<3;row++)
	{
		for(int col=0;col<3;col++)
		{
			cout<<"\t"<<mat[row][col];
		}
		cout<<"\n";
	}
	cout<<"\n";
	for(int i=0;i<3;i++)
	{
		vec1[i]=rand()%300;
		vec2[i]=rand()%200;
	}

	for(int i=0;i<3;i++)
	{
		cout<<"VECTOR 1:"<<vec1[i]<<endl;
	}

	cout<<"\n";
	for(int i=0;i<3;i++)
	{
		cout<<"VECTOR 2:"<<vec2[i]<<endl;
	}
	cout<<"\n";
	clock_t c1=omp_get_wtime();
	#pragma omp parallel
	{
		#pragma omp paralle for
		for(int row=0;row<3;row++)
		{	out[row]=0;
			for(int col=0;col<3;col++)
			{
				out[row]=mat[row][col]*vec1[col]+out[row];
			}
		}
	}
	float t1=(float)(omp_get_wtime()-c1)/CLOCKS_PER_SEC;
	for(int i=0;i<3;i++)
	{
		cout<<"OUT:"<<out[i]<<endl;
	}
	cout<<"\n Execution time for matrix vector multiplication:"<<t1<<endl;

	clock_t c2=omp_get_wtime();
	#pragma omp parallel for
	for(int i=0;i<3;i++)
	{
		veco[i]=vec1[i]+vec2[i];
	}
	float t2=(float)(omp_get_wtime()-c2)/CLOCKS_PER_SEC;
	for(int i=0;i<3;i++)
	{
		cout<<"VECTOR OUT"<<veco[i]<<endl;
	}
	cout<<"Execution time for vector addition:"<<t2<<endl;


	//SERIAL MULTIPLICATION
	clock_t c3=clock();
	for(int row=0;row<3;row++)
		{	out1[row]=0;
			for(int col=0;col<3;col++)
			{
				out1[row]=mat[row][col]*vec1[col]+out1[row];
			}
		}
	float t3=(float)(clock()-c3)/CLOCKS_PER_SEC;
	for(int i=0;i<3;i++)
	{
		cout<<"OUT:"<<out1[i]<<endl;
	}
	cout<<"\n Execution time for matrix vector multiplication(SERIAL):"<<t3<<endl;


	clock_t c4=clock();
	for(int i=0;i<3;i++)
	{
		veco1[i]=vec1[i]+vec2[i];
	}
	float t4=(float)(clock()-c4)/CLOCKS_PER_SEC;
	for(int i=0;i<3;i++)
	{
		cout<<"VECTOR OUT"<<veco1[i]<<endl;
	}
	cout<<"Execution time for vector addition(SERIAL):"<<t4<<endl;



	return 0;

}