#include<iostream>
#include<time.h>
#include<stdlib.h>
#include<omp.h>
using namespace std;


int main()
{
	int n;
	cout<<"ENTER N:";
	cin>>n;
	int mat1[n][n],mat2[n][n],vec[n],outm[n][n],outv[n];

	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			mat1[row][col]=rand()%10;
			mat2[row][col]=rand()%10;
		}
	}

	for(int i=0;i<n;i++)
	{
		vec[i]=rand()%15;
	}

	cout<<"MATRIX 1:"<<endl;
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			cout<<"\t"<<mat1[row][col];
		}
		cout<<"\n";
	}

	cout<<"MATRIX 2:"<<endl;
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			cout<<"\t"<<mat2[row][col];
		}
		cout<<"\n";
	}

	cout<<"Vector:"<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<vec[i]<<endl;
	}
	clock_t c1=omp_get_wtime();
	#pragma omp parallel for
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{	
			outm[row][col]=0;
			for(int m=0;m<n;m++)
			{
				outm[row][col]=mat1[row][m]*mat2[m][col]+outm[row][col];
			}
		}
	}
	cout<<"\n";
	float t1=(float)(omp_get_wtime()-c1)/CLOCKS_PER_SEC;
	cout<<"EXECUTION TIME FOR PARALLE MULTIPLICATION:"<<t1<<endl;

	cout<<"MATRIX OUTPUT:"<<endl;
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			cout<<"\t"<<outm[row][col];
		}
		cout<<"\n";
	}

	clock_t c2=omp_get_wtime();	
	#pragma omp parallel for
	for(int row=0;row<n;row++)
	{
		outv[row]=0;
		for(int col=0;col<n;col++)
		{
			outv[row]=mat1[row][col]*vec[col]+outv[row];
		}
	}
	cout<<"\n";
	float t2=(float)(omp_get_wtime()-c2)/CLOCKS_PER_SEC;
	for(int i=0;i<n;i++)
	{
		cout<<"VECTOR OUT:"<<outv[i]<<endl;
	}
	cout<<"EXECUTION TIME FOR PARALLEL VECTOR MATRIX MUL:"<<t2<<endl;




}