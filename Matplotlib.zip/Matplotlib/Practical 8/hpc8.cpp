#include<iostream>
#include<stdlib.h>
#include<omp.h>
#include<time.h>
using namespace std;

void swap(int &a1,int &b1)
{
	int temp=a1;
	a1=b1;
	b1=temp;
}

void bubble(int *a,int n)
{
	for(int i=0;i<n;i++)
	{
		int first=i%2;
		#pragma omp parallel for shared(a,first,n)
		for(int j=first;j<n-1;j+=2)
		{
			if(a[j]>a[j+1])
			{
				swap(a[j],a[j+1]);
			}
		}
	}
}

void merge(int a[],int i1,int j1,int i2,int j2)
{
	int temp[1000];
	int i=i1;
	int j=i2;
	int k=0;
	while(i<=j1 && j<=j2)
	{
		if(a[i]<a[j])
		{
			temp[k]=a[i];
			k++;
			i++;
		}
		else
		{
			temp[k]=a[j];
			k++;
			j++;
		}
	}
	while(i<=j1)
	{
		temp[k]=a[i];
		k++;
		i++;
	}
	while(j<=j2)
	{
		temp[k]=a[j];
		k++;
		j++;
	}
	for(i=i1,j=0;i<=j2;i++,j++)
	{
		a[i]=temp[j];
	}
}

void mergesort(int a[],int i,int j)
{
	int mid;
	if(i<j)
	{
		mid=(i+j)/2;
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				mergesort(a,i,mid);
			}
			#pragma omp section
			{
				mergesort(a,mid+1,j);
			}
		}
		merge(a,i,mid,mid+1,j);
	}
}

int main()
{
	int n;
	cout<<"Enter no. of elements:";
	cin>>n;
	int a[n],a1[n],c=(n*2);
	for(int i=0;i<n;i++)
	{
		a[i]=rand()%c;
		a1[i]=a[i];
	}
	clock_t c1=omp_get_wtime();
	bubble(a,n);
	float t1=(float)(omp_get_wtime()-c1)/CLOCKS_PER_SEC;
	cout<<"Sorted array is(BUBBLE SORT):"<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<"\t";
	}
	cout<<"\nEXECUTION TIME FOR BUBBLE SORT:"<<t1<<endl;
	mergesort(a1,0,n-1);
	cout<<"SORTED ARRAY(MERGE SORT):"<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<a1[i]<<"\t";
	}
	cout<<"\n";
}