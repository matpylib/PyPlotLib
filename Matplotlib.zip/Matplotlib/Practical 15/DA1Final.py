#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[2]:


db=pd.read_csv(r"C:\Users\rdrl\Desktop\DA Practical\Assignment1\iris.csv")


# In[3]:


db.describe()


# In[33]:


db.info()


# In[4]:


print(db.columns)


# In[5]:


print(len(db.columns))


# In[7]:


print(type(db.columns))


# In[9]:


db.mean()


# In[10]:


db.max()


# In[11]:


db.min()


# In[13]:


db.std()


# In[14]:


db.var()


# In[21]:


plt.hist(db["Sepal Length"])


# In[22]:


plt.hist(db["Sepal Width"])


# In[23]:


plt.hist(db["Petal Length"])


# In[24]:


plt.hist(db["Petal Width"])


# In[25]:


plt.boxplot(db["Petal Width"])


# In[27]:


plt.boxplot(db["Petal Length"])


# In[28]:


plt.boxplot(db["Sepal Length"])


# In[29]:


plt.boxplot(db["Sepal Width"])


# In[31]:


db.boxplot()


# In[ ]:





# In[ ]:




