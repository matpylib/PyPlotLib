#include<omp.h>
#include<iostream>
#include<stdlib.h>
#include<time.h>
using namespace std;

int main()
{
	int n;
	cout<<"Enter no. of elements:";
	cin>>n;
	int arr[n],sum=0,sum1=0;
	float avg=0;

	int c=2*n;
	for(int i=0;i<n;i++)
	{
		arr[i]=rand()%c;
	}

	//PARALLEL SUM
	clock_t c1=omp_get_wtime();
	#pragma omp parallel for reduction(+:sum)
	for(int i=0;i<n;i++)
	{
		sum=sum+arr[i];
	}
	float t1=(float)(omp_get_wtime()-c1)/CLOCKS_PER_SEC;
	cout<<"SUM:"<<sum<<endl;
	cout<<"EXECUTION TIME FOR SUM:"<<t1<<endl;



	//PARALLEL AVERAGE
	clock_t c2=omp_get_wtime();
	#pragma omp parallel for reduction(+:sum1)
	for(int i=0;i<n;i++)
	{
		sum1=sum1+arr[i];
	}
	avg=(float)sum1/n;
	float t2=(float)(omp_get_wtime()-c2)/CLOCKS_PER_SEC;
	cout<<"AVG:"<<avg<<endl;
	cout<<"EXECUTION TIME FOR SUM:"<<t2<<endl;

	//SEQUENTIAL SUM
	int sum2=0;
	clock_t c3=clock();
	for(int i=0;i<n;i++)
	{
		sum2=sum2+arr[i];
	}
	float t3=(float)(clock()-c3)/CLOCKS_PER_SEC;
	cout<<"SEQUENTIAL SUM:"<<sum2;
	cout<<"SEQUENTIAL TIME FOR SUM:"<<t3;



	//SEQUENTIAL AVERAGE
	int sum3=0;
	clock_t c4=clock();
	for(int i=0;i<n;i++)
	{
		sum3=sum3+arr[i];
	}
	float avgs=(float)(sum3/n);
	float t4=(float)(clock()-c4)/CLOCKS_PER_SEC;
	cout<<"SEQUENTIAL SUM:"<<avgs;
	cout<<"SEQUENTIAL TIME FOR SUM:"<<t4;

	return 0;



}