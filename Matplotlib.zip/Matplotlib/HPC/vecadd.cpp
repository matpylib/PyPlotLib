#include<stdio.h>
#include<iostream>
#include<cstdlib>
//****important to add following library to allow a programmer to use parallel paradigms*****
#include<omp.h>	
using namespace std;
#define MAX 10
int main()
{
	int a[MAX], b[MAX], c[MAX], i;
	float t_1 , t_2; // Execution time measures
	clock_t c_1, c_2;
	printf("\n Enter First Vector:\t");

	//Instruct a master thread to fork and generate more threads to process following loop structure
	for (i = 0; i<MAX; i++)
	{
		cin >> a[i];
	}

	//Discuss issue of this for loop below-if we make it parallel, possibly values that get printed will not be in sequence as we dont have any control on order of threads execution
	for (i = 0; i<MAX; i++)
	{
		printf("%d\t", a[i]);
	}

	printf("\n Enter Second Vector:\t");

	for (i = 0; i<MAX; i++)
	{
		cin >> b[i];
	}

	for (i = 0; i<MAX; i++)
	{
		printf("%d\t", b[i]);
	}

	printf("\n Parallel-Vector Addition:(a,b,c)\t");

	c_1 = clock();
	printf("Max number of threads: %i \n", omp_get_max_threads());

	printf("Number of threads: %i \n", omp_get_num_threads());
	
      #pragma omp parallel for
	
	for (i = 0; i<MAX; i++)
	{
		c[i] = a[i] + b[i];
	}

	for (i = 0; i<MAX; i++)
	{
		printf("\n%d\t%d\t%d", a[i], b[i], c[i]);
	}
	
	/* TIME MEASURE + OUTPUT */
	 // time measure: 
	t_1 = (float)(clock() - c_1) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("Execution time of Parallel : %f(in seconds) \n", t_1);
	
	printf("\n Serial-Vector Addition:(a,b,c)\t");
	
	c_2 = clock();
	
	printf("Max number of threads: %i \n", omp_get_max_threads());

	
	printf("Number of threads: %i \n", omp_get_num_threads());
	

	for (i = 0; i<MAX; i++)
	{
		c[i] = a[i] + b[i];
	}

	for (i = 0; i<MAX; i++)
	{
		printf("\n%d\t%d\t%d", a[i], b[i], c[i]);
	}
	
	/* TIME MEASURE + OUTPUT */
	 // time measure: 
	t_2 = (float)(clock() - c_2) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("Execution time of Serial : %f(in seconds) \n", t_2);
	
	system("pause");
	return 0;
}
