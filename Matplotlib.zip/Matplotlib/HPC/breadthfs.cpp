#include<iostream>
#include<stdlib.h>
#include<queue>
using namespace std;


class node
{
public:

	node * left, *right;
	int data;

};

class Breadthfs
{

public:

	node * insert(node *, int);
	void bfs(node *);

};


node *insert(node *root, int data)
{

	if (!root)
	{

		root = new node;
		root->left = NULL;
		root->right = NULL;
		root->data = data;
		return root;
	}

	queue<node *> q;
	q.push(root);

	while (!q.empty())
	{

		node *temp = q.front();
		q.pop();

		if (temp->left == NULL)
		{

			temp->left = new node;
			temp->left->left = NULL;
			temp->left->right = NULL;
			temp->left->data = data;
			return root;
		}
		else
		{

			q.push(temp->left);

		}

		if (temp->right == NULL)
		{

			temp->right = new node;
			temp->right->left = NULL;
			temp->right->right = NULL;
			temp->right->data = data;
			return root;
		}
		else
		{

			q.push(temp->right);

		}

	}

}


void bfs_parallel(node *head , int element)
{

	queue<node*> q;
	q.push(head);

	int qSize , flag = 0;

	while (!q.empty())
	{
		qSize = q.size();
#pragma omp parallel for
		for (int i = 0; i < qSize; i++)
		{
			node* currNode;
#pragma omp critical
			{
				currNode = q.front();
				if(currNode->data == element)
				{
					flag = 1;
				}
				q.pop();
				cout << "\t" << currNode->data;

			}
#pragma omp critical
			{
				if (currNode->left)
					q.push(currNode->left);
				if (currNode->right)
					q.push(currNode->right);
			}

		}
	}
	if(flag == 0)
	{
		cout<<"\tElement not found\t";
	}
	else
	{
		cout<<"\tElement Found\t";
	}

}

void bfs_serial(node *head , int element)
{

	queue<node*> q;
	q.push(head);

	int qSize , flag=0;

	while (!q.empty())
	{
		qSize = q.size();

		for (int i = 0; i < qSize; i++)
		{
			node* currNode;

			{
				currNode = q.front();
				if(currNode->data == element)
				{
					flag = 1;
				}
				q.pop();
				cout << "\t" << currNode->data;

			}

			{
				if (currNode->left)
					q.push(currNode->left);
				if (currNode->right)
					q.push(currNode->right);
			}

		}
	}
	if(flag == 0)
	{
		cout<<"\tElement not found\t";
	}
	else
	{
		cout<<"\tElement Found\t";
	}

}

int main() {

	node *root = NULL;
	int data , element;
	char ans;

	do
	{
		cout << "\n enter data=>";
		cin >> data;

		root = insert(root, data);

		cout << "do you want insert one more node?";
		cin >> ans;

	} while (ans == 'y' || ans == 'Y');
	
	cout<<"\nEnter element to be searched\n";
	cin>>element;
	
	clock_t timer1 = clock();
	bfs_parallel(root , element);
	cout<<"\n Time for parallel breadth first search : "<<(float)(clock() - timer1)/CLOCKS_PER_SEC<<"\n";
	
	cout<<"\n";
	
	clock_t timer2 = clock();
	bfs_serial(root,element);
	cout<<"\n Time for serial breadth first search : "<<(float)(clock() - timer2)/CLOCKS_PER_SEC<<"\n";
	
	system("pause");

	return 0;
}

/*

	sushrut7898@ubuntu:~/Documents/HPC$ g++ breadthfs.cpp -fopenmp -o bfs
	sushrut7898@ubuntu:~/Documents/HPC$ ./bfs


*/
