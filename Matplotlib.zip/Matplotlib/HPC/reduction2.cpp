#include <stdio.h>
#include <omp.h>
#include <time.h>

int main()
{
    int arr[10];
    omp_set_num_threads(10);
    int sum_value=0 ;
    float average_value;
    int i;
    printf("Enter the elements \n");
    for( i=0; i<10; i++)
        scanf("%d",&arr[i]);
     
    //P A R A L L E L    S U M
        
    clock_t c_1 = clock();
    
    #pragma omp parallel for reduction(+ : sum_value)
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        sum_value = sum_value + arr[i];
    }
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_1 = (float)(clock() - c_1) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Parallel : %f(in seconds) \n", t_1);
  
    printf("\nSum is = %d", sum_value);
    
    //S E R I A L        S U M
    sum_value =0;
    clock_t c_2 = clock();
    
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        sum_value += arr[i];
    }
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_2 = (float)(clock() - c_2) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Serial : %f(in seconds) \n", t_2);
  
    printf("\nSum is = %d", sum_value);
    
    //P A R A L L E L    M E A N
        
    clock_t c_3 = clock();
    sum_value =0;
    #pragma omp parallel for reduction(+ : average_value)
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        sum_value = sum_value + arr[i];
        
    }
    average_value = (float)sum_value/10;
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_3 = (float)(clock() - c_3) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Parallel : %f(in seconds) \n", t_3);
  
    printf("\nAverage Value = %f", average_value);
    
    //S E R I A L        M E A N
    
    clock_t c_4 = clock();
    sum_value =0;
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        sum_value += arr[i];
        
    }
    average_value = (float)sum_value/10;
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_4 = (float)(clock() - c_4) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Serial : %f(in seconds) \n", t_4);
  
    printf("\nAverage Value = %f", average_value);
}

/*

sushrut7898@ubuntu:~/Documents/HPC$ g++ reduction2.cpp -fopenmp -o red2
sushrut7898@ubuntu:~/Documents/HPC$ ./red2

Enter the elements 
1
2
3
4
5
6
7
8
9
10

thread id = 2 and i = 2
thread id = 3 and i = 3
thread id = 4 and i = 4
thread id = 5 and i = 5
thread id = 6 and i = 6
thread id = 7 and i = 7
thread id = 8 and i = 8
thread id = 9 and i = 9
thread id = 0 and i = 0
thread id = 1 and i = 1
Execution time of Parallel : 0.002198(in seconds) 

Sum is = 55
thread id = 0 and i = 0
thread id = 0 and i = 1
thread id = 0 and i = 2
thread id = 0 and i = 3
thread id = 0 and i = 4
thread id = 0 and i = 5
thread id = 0 and i = 6
thread id = 0 and i = 7
thread id = 0 and i = 8
thread id = 0 and i = 9
Execution time of Serial : 0.000046(in seconds) 

Sum is = 55
thread id = 4 and i = 4
thread id = 2 and i = 2
thread id = 3 and i = 3
thread id = 5 and i = 5
thread id = 8 and i = 8
thread id = 0 and i = 0
thread id = 1 and i = 1
thread id = 6 and i = 6
thread id = 7 and i = 7
thread id = 9 and i = 9
Execution time of Parallel : 0.000403(in seconds) 

Average Value = 5.500000
thread id = 0 and i = 0
thread id = 0 and i = 1
thread id = 0 and i = 2
thread id = 0 and i = 3
thread id = 0 and i = 4
thread id = 0 and i = 5
thread id = 0 and i = 6
thread id = 0 and i = 7
thread id = 0 and i = 8
thread id = 0 and i = 9
Execution time of Serial : 0.000044(in seconds) 

Average Value = 5.500000

*/
