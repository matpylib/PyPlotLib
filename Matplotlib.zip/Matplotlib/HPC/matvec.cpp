#include<stdio.h>
#include<iostream>
#include<cstdlib>
#include<omp.h>
using namespace std;
#define m 3
#define n 3


int main()
{
	float t_1 , t_2; // Execution time measures
	clock_t c_1, c_2;
	int mat[m][n], vec[n], out[m];

	//matrix of size 3x3
	cout<<"\nEnter elements of 3 * 3 Matrix\n";
	for (int row = 0; row<m; row++)
	{
		for (int col = 0; col<n; col++)
		{
			cin>>mat[row][col];
		}
	}
	//display matrix
	cout << "Input Matrix" << endl;
	for (int row = 0; row<m; row++)
	{
		for (int col = 0; col<n; col++)
		{
			cout << "\t" << mat[row][col];
		}
		cout << "" << endl;
	}


	//column vector of size 3x1
	cout<<"\nEnter elements of 3 * 1 Vector\n";
	for (int row = 0; row<n; row++)
	{
		cin >> vec[row];
	}

	//display vector
	cout << "Input Col-Vector" << endl;
	for (int row = 0; row<n; row++)
	{
		cout << vec[row] << endl;
	}



	c_1 = clock();

	//before multiplication check condition, no_of_cols(matrix)==no_of_rows(vector)
#pragma omp parallel
	{
#pragma omp parallel for
		for (int row = 0; row<m; row++)
		{
			out[row] = 0;
			for (int col = 0; col<n; col++)
			{
				out[row] += mat[row][col] * vec[col];
				//int count=out[row];
				//printf("\n%d\n",count);
			}
		}

	}
	/* TIME MEASURE + OUTPUT */
	 // time measure: 
	t_1 = (float)(clock() - c_1) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("Execution time of Parallel : %f(in seconds) \n", t_1);
	
	
	
	//display resultant vector
	cout << "Resultant Col-Vector" << endl;

	for (int row = 0; row<m; row++)
	{
		cout << "\nvec[" << row << "]:" << out[row] << endl;
	}
	
	c_2 = clock();

	//before multiplication check condition, no_of_cols(matrix)==no_of_rows(vector)

	{
		for (int row = 0; row<m; row++)
		{
			out[row] = 0;
			for (int col = 0; col<n; col++)
			{
				out[row] += mat[row][col] * vec[col];
				//int count=out[row];
				//printf("\n%d\n",count);
			}
		}

	}
	/* TIME MEASURE + OUTPUT */
	 // time measure: 
	t_2 = (float)(clock() - c_2) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("Execution time of Serial : %f(in seconds) \n", t_2);
	

	//display resultant vector
	cout << "Resultant Col-Vector" << endl;

	for (int row = 0; row<m; row++)
	{
		cout << "\nvec[" << row << "]:" << out[row] << endl;
	}
	
	
	system("pause");
	return 0;
}


