#include<iostream>
#include<stdlib.h>
#include<omp.h>
#include<ctime>
using namespace std;

void bubble(int *, int);
void swap(int &, int &);

void bubble_parallel(int *a, int n)
{
	for (int i = 0; i < n; i++)
	{
		int first = i % 2;
		#pragma omp parallel for shared(a,first)
		for (int j = first; j < n - 1; j += 2)
		{
			if (a[j]  >  a[j + 1])
			{
				swap(a[j], a[j + 1]);
			}
		}
	}
}

void bubble_serial(int *a, int n)
{
	for (int i = 0; i < n; i++)
	{
		int first = i % 2;
//#pragma omp parallel for shared(a,first)
		for (int j = first; j < n - 1; j += 2)
		{
			if (a[j]  >  a[j + 1])
			{
				swap(a[j], a[j + 1]);
			}	
		}
	}
}


void swap(int &a, int &b)
{
	int test;
	test = a;
	a = b;
	b = test;
}

int main()
{

	int *a, n;
	cout << "\n enter total no of elements=>";
	cin >> n;
	a = new int[n];

//	cout << "\n enter elements=>";
	for (int i = 0; i < n; i++)
	{
		a[i]=rand()%5;
	}

	clock_t timer1 = clock();
	bubble_parallel(a, n);
	cout<<"\n Time for parallel bubble sort : "<<(float)(clock() - timer1)/CLOCKS_PER_SEC<<"\n";

	/*cout << "\n sorted array is=>\n";
	for (int i = 0; i < n; i++)
	{
		cout << a[i] << endl;
	}
*/
	clock_t timer2 = clock();
	bubble_serial(a, n);
	cout<<"\n Time for serial bubble sort : "<<(float)(clock() - timer2)/CLOCKS_PER_SEC<<"\n";

	/*cout << "\n sorted array is=>\n";
	for (int i = 0; i < n; i++)
	{
		cout << a[i] << endl;
	}
*/
	system("pause");
	return 0;
}
