#include <stdio.h>
#include <omp.h>
#include <time.h>

int main()
{
    int arr[10];
   // omp_set_num_threads(10);
    int max_val=0 , min_val=999999;
    int i;
    printf("Enter the elements \n");
    for( i=0; i<10; i++)
        scanf("%d",&arr[i]);
     
    //P A R A L L E L    M A X
        
    clock_t c_1 = clock();
    
    #pragma omp parallel for reduction(max : max_val)
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        if(arr[i] > max_val)
        {
            max_val = arr[i];  
        }
    }
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_1 = (float)(clock() - c_1) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Parallel : %f(in seconds) \n", t_1);
  
    printf("\nmax_val = %d", max_val);
    
    //S E R I A L        M A X
    
    clock_t c_2 = clock();
    
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        if(arr[i] > max_val)
        {
            max_val = arr[i];  
        }
    }
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_2 = (float)(clock() - c_2) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Serial : %f(in seconds) \n", t_2);
  
    printf("\nmax_val = %d", max_val);
    
    //P A R A L L E L    M I N
        
    clock_t c_3 = clock();
    
    #pragma omp parallel for reduction(min : min_val)
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        if(arr[i] < min_val)
        {
            min_val = arr[i];  
        }
    }
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_3 = (float)(clock() - c_3) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Parallel : %f(in seconds) \n", t_3);
  
    printf("\nmin_val = %d", min_val);
    
    //S E R I A L        M I N
    
    clock_t c_4 = clock();
    
    for( i=0;i<10; i++)
    {
        printf("\nthread id = %d and i = %d", omp_get_thread_num(), i);
        if(arr[i] < min_val)
        {
            min_val = arr[i];  
        }
    }
    
    /* TIME MEASURE + OUTPUT */
	 // time measure: 
	float t_4 = (float)(clock() - c_4) / CLOCKS_PER_SEC; // in seconds; - time elapsed for job row-wise
	printf("\nExecution time of Serial : %f(in seconds) \n", t_4);
  
    printf("\nmin_val = %d", min_val);
}

/*

sushrut7898@ubuntu:~/Documents/HPC$ g++ dummy.cpp -fopenmp -o dummy
sushrut7898@ubuntu:~/Documents/HPC$ ./dummy

Enter the elements 
11

15
16
17
81
82
83
24
26
91

thread id = 2 and i = 2
thread id = 0 and i = 0
thread id = 5 and i = 5
thread id = 3 and i = 3
thread id = 7 and i = 7
thread id = 4 and i = 4
thread id = 1 and i = 1
thread id = 8 and i = 8
thread id = 9 and i = 9
thread id = 6 and i = 6
Execution time of Parallel : 0.000516(in seconds) 

max_val = 91
thread id = 0 and i = 0
thread id = 0 and i = 1
thread id = 0 and i = 2
thread id = 0 and i = 3
thread id = 0 and i = 4
thread id = 0 and i = 5
thread id = 0 and i = 6
thread id = 0 and i = 7
thread id = 0 and i = 8
thread id = 0 and i = 9
Execution time of Serial : 0.000030(in seconds) 

max_val = 91
thread id = 3 and i = 3
thread id = 0 and i = 0
thread id = 9 and i = 9
thread id = 5 and i = 5
thread id = 4 and i = 4
thread id = 2 and i = 2
thread id = 6 and i = 6
thread id = 7 and i = 7
thread id = 8 and i = 8
thread id = 1 and i = 1
Execution time of Parallel : 0.000115(in seconds) 

min_val = 11
thread id = 0 and i = 0
thread id = 0 and i = 1
thread id = 0 and i = 2
thread id = 0 and i = 3
thread id = 0 and i = 4
thread id = 0 and i = 5
thread id = 0 and i = 6
thread id = 0 and i = 7
thread id = 0 and i = 8
thread id = 0 and i = 9
Execution time of Serial : 0.000012(in seconds) 

min_val = 11

*/
