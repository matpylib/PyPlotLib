#include<iostream>
#include<time.h>
#include<omp.h>
#include<stdlib.h>
using namespace std;

int main()
{
	int n;
	cout<<"ENTER N:";
	cin>>n;
	int mat1[n][n],mat2[n][n],vec1[n],vec2[n],outm[n][n],outv[n];

	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			mat1[row][col]=rand()%10;
			mat2[row][col]=rand()%15;
		}
	}
	cout<<"MATRIX 1:"<<endl;
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			cout<<"\t"<<mat1[row][col];	
		}
		cout<<"\n";
	}
	
	cout<<"MATRIX 2:"<<endl;
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			cout<<"\t"<<mat2[row][col];	
		}
		cout<<"\n";
	}
	


	for(int i=0;i<n;i++)
	{
		vec1[i]=rand()%20;
		vec2[i]=rand()%20;
	}
	cout<<"VECTOR 1:"<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<vec1[i]<<endl;
	}
	cout<<"\nVECTOR 2:"<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<vec2[i]<<endl;
	}
	clock_t c1=omp_get_wtime();
	#pragma omp parallel for 
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			outm[row][col]=0;
			for(int m=0;m<n;m++)
			{
				outm[row][col]=mat1[row][m]*mat2[m][col]+outm[row][col];
			}
		}
	}
	float t1=(float)(omp_get_wtime()-c1)/CLOCKS_PER_SEC;
	cout<<"RESULT MATRIX:"<<endl;
	for(int row=0;row<n;row++)
	{
		for(int col=0;col<n;col++)
		{
			cout<<"\t"<<outm[row][col];	
		}
		cout<<"\n";
	}
	cout<<"TIME FOR PARALLEL MULTIPLICATION:"<<t1<<endl;
	
	clock_t c2=omp_get_wtime();
	#pragma omp parallel for
	for(int i=0;i<n;i++)
	{
		outv[i]=vec1[i]+vec2[i];
	}
	float t2=(float)(omp_get_wtime()-c2)/CLOCKS_PER_SEC;
	cout<<"OUT VECTOR:"<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<"VECTOR:"<<outv[i]<<endl;
	}
	cout<<"\nTIME FOR PARALLEL VECTOR ADDITION:"<<t2<<endl;


	return 0;
}